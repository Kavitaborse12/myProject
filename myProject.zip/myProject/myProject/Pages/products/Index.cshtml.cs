using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Data.SqlClient;
using System.Diagnostics;

namespace myProject.Pages.products
{
    public class IndexModel : PageModel
    {
        public List<ProductInfo> listProducts = new List<ProductInfo>();
        public void OnGet()
        {
            try
            {
                String connectionString = "Data Source=DESKTOP-4VRT75J\\SQLEXPRESS;Initial Catalog=myProject;Integrated Security=True";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    String sql = "SELECT * FROM products";
                    using (SqlCommand command = new SqlCommand(sql, connection))
                    {
                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                ProductInfo productInfo = new ProductInfo();
                                productInfo.id = "" + reader.GetInt32(0);
                                productInfo.product = reader.GetString(1);
                                productInfo.description = reader.GetString(2);
                                productInfo.created = reader.GetDateTime(5).ToString();

                                listProducts.Add(productInfo);
                            }        

                            }
                        }

                    }
                }
            catch (Exception ex)
            {
                Console.WriteLine("Exception: " + ex.ToString());           
            }
        }
    }



    public class ProductInfo
    {
        public String id;
        public String product;
        public String description;
        public String created;
        public String action;
    }
}