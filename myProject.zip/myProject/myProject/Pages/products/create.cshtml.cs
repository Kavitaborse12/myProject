using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Data.SqlClient;

namespace myProject.Pages.products
{
   
    public class createModel : PageModel
    {
        public ProductInfo productInfo = new ProductInfo();
        public String errorMessage = "";
        public string successMessage= "";

        public void OnGet()
        {
        }

        public void OnPost()
        {
            productInfo.product = Request.Form["product"];
            productInfo.description = Request.Form["description"];
            productInfo.created = Request.Form["created"];

            if (productInfo.product.Length == 0 ||  productInfo.description.Length == 0 ||
                productInfo.created.Length == 0)
            {
                errorMessage = "All the fields are required";
                return;
            }
            // save the new products into database
            try
            {
                String connectionString = "Data Source=DESKTOP-4VRT75J\\SQLEXPRESS;Initial Catalog=myProject;Integrated Security=True";
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    String sql = "INSERT INTO products" +
                        "(product, description,created) VALUES " +
                        "(@product, @description,@created);";

                    using (SqlCommand command = new SqlCommand(sql, connection))
                    {
                        command.Parameters.AddWithValue("@product", productInfo.product);
                        command.Parameters.AddWithValue("@description", productInfo.description);
                        command.Parameters.AddWithValue("@created", productInfo.created);

                        command.ExecuteNonQuery();
                    }

                }
            }
            catch(Exception ex)
            {
                errorMessage = ex.Message;
                return;
            }
            productInfo.product = ""; productInfo.description = ""; productInfo.created = "";
            successMessage = "New Product Added Successfully";

            Response.Redirect("/products/Index");
        }
    }
}
