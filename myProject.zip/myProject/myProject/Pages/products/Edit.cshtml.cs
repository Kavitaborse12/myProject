using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Data.SqlClient;
using System.Reflection.PortableExecutable;


namespace myProject.Pages.products
{
    public class EditModel : PageModel
    {
        public ProductInfo productInfo = new ProductInfo();
        public String errorMessage = "";
        public String successMessage = "";

        public void OnGet()
        {
           
            try
            {
                String id = Request.Query["id"];

                String connectionString ="Data Source=DESKTOP-4VRT75J\\SQLEXPRESS;Initial Catalog=myProject;Integrated Security=True";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    String sql = "SELECT * FROM products WHERE id=@id";
                    using (SqlCommand command = new SqlCommand(sql, connection))
                    {
                        command.Parameters.AddWithValue("@id", id);
                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                productInfo.id = "" + reader.GetInt32(0);
                                productInfo.product = reader.GetString(1);
                                productInfo.description = reader.GetString(2);
                                productInfo.created = reader.GetDateTime(5).ToString();
                            }

                        }
                    }

                }

            }
            catch (Exception ex)
            {
                errorMessage = ex.Message;

            }
        }

        public void OnPost()
        {
            productInfo.id = Request.Form["id"];
            productInfo.product = Request.Form["product"];
            productInfo.description = Request.Form["description"];
            productInfo.created = Request.Form["created"];

            if (productInfo.id.Length == 0 || productInfo.product.Length == 0 ||
                productInfo.description.Length == 0 || productInfo.created.Length == 0)
            {
                errorMessage = "All the fields are required";
                return;
            }

            try
            {
                String connectionString = "Data Source=DESKTOP-4VRT75J\\SQLEXPRESS;Initial Catalog=myProject;Integrated Security=True";
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    String sql = "UPDATE products" +
                        "SET id=@id, product=@product, description=@description, created=@created" +
                        "WHERE id=@id";
                    
                using (SqlCommand command = new SqlCommand(sql, connection))
                {
                        command.Parameters.AddWithValue("@product", productInfo.product);
                        command.Parameters.AddWithValue("@description", productInfo.description);
                        command.Parameters.AddWithValue("@created", productInfo.created);
                        command.Parameters.AddWithValue("@id", productInfo.id);

                        command.ExecuteNonQuery();
                    }

                }
            }
            catch (Exception ex)
            {
                errorMessage=ex.Message;
                return;
            }
            Response.Redirect("/products/Index");
        }
     }
  }
